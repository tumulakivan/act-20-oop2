import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainForm {
    private JPanel MainForm;
    private JLabel lblRegForm;
    private JPanel panelHeader;
    private JPanel panelForm;
    private JPanel panelLabels;
    private JPanel panelForms;
    private JLabel lblLastName;
    private JLabel lblFirstName;
    private JLabel lblMidName;
    private JLabel lblAge;
    private JLabel lblSex;
    private JLabel lblAddress;
    private JTextField txtLastName;
    private JTextField txtFirstName;
    private JTextField txtMidName;
    private JTextField txtAge;
    private JComboBox cbSex;
    private JTextField txtAddress;
    private JButton btnSubmit;
    private JButton btnClear;

    public MainForm() {
        btnSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnSubmitShowActionPerformed(e);
            }
        });

        btnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnClearShowActionPerformed(e);
            }
        });
    }

    private void btnSubmitShowActionPerformed(java.awt.event.ActionEvent event) {
        try {
            String selectedSex = (String) cbSex.getSelectedItem();
            String name = txtFirstName.getText() + " " + txtMidName.getText() + " " + txtLastName.getText();
            if(txtLastName.getText() == "" || txtFirstName.getText() == "" || txtMidName.getText() == "" || txtAge.getText() == "" || selectedSex == "Choose" || txtAddress.getText() == "") {
                throw new Exception();
            }

            if(Integer.parseInt(txtAge.getText()) < 0) {
                throw new IllegalArgumentException("Age cannot be below zero.");
            } else if(Integer.parseInt(txtAge.getText()) == 1) {
                JOptionPane.showMessageDialog(MainForm, "You are registered! " + name + ", " + txtAge.getText() + " year old, " + selectedSex + " from " + txtAddress.getText(), "Congratulations!", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(MainForm, "You are registered! " + name + ", " + txtAge.getText() + " years old, " + selectedSex + " from " + txtAddress.getText(), "Congratulations!", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch(IllegalArgumentException e) {
            JOptionPane.showMessageDialog(MainForm, e.getMessage(), "ERROR", JOptionPane.INFORMATION_MESSAGE);
        } catch(Exception e) {
            JOptionPane.showMessageDialog(MainForm, "All fields are required.", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void btnClearShowActionPerformed(java.awt.event.ActionEvent event) {
        txtLastName.setText("");
        txtFirstName.setText("");
        txtMidName.setText("");
        txtAge.setText("");
        cbSex.setSelectedIndex(0);
        txtAddress.setText("");
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("MainForm");
        frame.setContentPane(new MainForm().MainForm);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
